# ShadowMesh v3 (Private Encrypted Squad Messenger)

Zero-internet, AES-256-GCM encrypted Android messenger with:
1. **MESH Mode**: Bluetooth + Wi-Fi Direct multi-hop relay (`TTL=5`) between squad phones.
2. **SMS 3KM+ Mode**: Long-range encrypted SMS (`#SM1:`) with background reception and local persistence.
3. **Local Chat Persistence & Wipe**: Messages persist locally across restarts and can be wiped instantly from SETUP.

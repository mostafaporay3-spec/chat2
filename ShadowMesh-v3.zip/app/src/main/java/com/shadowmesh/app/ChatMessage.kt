package com.shadowmesh.app

data class ChatMessage(
    val sender: String,
    val body: String,
    val transport: String,
    val timestamp: String,
    val isMine: Boolean
)

package com.shadowmesh.app

import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ChatAdapter(private val items: MutableList<ChatMessage>) :
    RecyclerView.Adapter<ChatAdapter.Holder>() {

    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val root: LinearLayout = view.findViewById(R.id.msgRoot)
        val bubble: LinearLayout = view.findViewById(R.id.msgBubble)
        val tvMeta: TextView = view.findViewById(R.id.tvMeta)
        val tvBody: TextView = view.findViewById(R.id.tvBody)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_message, parent, false)
        return Holder(v)
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val msg = items[position]
        holder.tvMeta.text = "${msg.sender}  |  ${msg.transport}  |  ${msg.timestamp}"
        holder.tvBody.text = msg.body
        holder.root.gravity = if (msg.isMine) Gravity.END else Gravity.START
        holder.bubble.setBackgroundResource(
            if (msg.isMine) R.drawable.bg_bubble_me else R.drawable.bg_bubble_other
        )
    }

    override fun getItemCount(): Int = items.size

    fun replaceAll(newItems: List<ChatMessage>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }
}

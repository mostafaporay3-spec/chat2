package com.shadowmesh.app

import android.content.Context

object Prefs {
    private const val FILE = "shadowmesh_prefs"
    private const val KEY_NICK = "nickname"
    private const val KEY_SECRET = "secret_key"
    private const val KEY_PHONES = "squad_phones"

    fun getNickname(ctx: Context): String =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY_NICK, "Agent") ?: "Agent"

    fun getSecretKey(ctx: Context): String =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY_SECRET, "Squad2026!") ?: "Squad2026!"

    fun getPhonesRaw(ctx: Context): String =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY_PHONES, "") ?: ""

    fun getPhoneList(ctx: Context): List<String> =
        getPhonesRaw(ctx)
            .lines()
            .map { it.trim() }
            .filter { it.isNotEmpty() }

    fun save(ctx: Context, nickname: String, secretKey: String, phonesRaw: String) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putString(KEY_NICK, nickname.trim().ifEmpty { "Agent" })
            .putString(KEY_SECRET, secretKey.trim().ifEmpty { "Squad2026!" })
            .putString(KEY_PHONES, phonesRaw.trim())
            .apply()
    }
}

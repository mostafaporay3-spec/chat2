package com.shadowmesh.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SmsReceiver : BroadcastReceiver() {
    companion object {
        const val PREFIX = "#SM1:"
        const val ACTION_MESSAGES_UPDATED = "com.shadowmesh.app.MESSAGES_UPDATED"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        if (messages.isNullOrEmpty()) return

        val grouped = mutableMapOf<String, StringBuilder>()
        for (sms in messages) {
            val from = sms.displayOriginatingAddress ?: "Unknown"
            val body = sms.messageBody ?: ""
            grouped.getOrPut(from) { StringBuilder() }.append(body)
        }

        val secret = Prefs.getSecretKey(context)
        val timeStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        var anySaved = false

        for ((phone, sb) in grouped) {
            val fullText = sb.toString().trim()
            if (!fullText.startsWith(PREFIX)) continue

            val cipherPart = fullText.removePrefix(PREFIX)
            val decrypted = CryptoHelper.decrypt(cipherPart, secret) ?: continue

            val (senderName, msgBody) = try {
                val obj = JSONObject(decrypted)
                obj.optString("u", phone) to obj.optString("m", decrypted)
            } catch (_: Exception) {
                phone to decrypted
            }

            MessageStore.saveMessage(
                context,
                ChatMessage(
                    sender = senderName,
                    body = msgBody,
                    transport = "SMS-AES",
                    timestamp = timeStr,
                    isMine = false
                )
            )
            anySaved = true
        }

        if (anySaved) {
            val uiIntent = Intent(ACTION_MESSAGES_UPDATED).apply {
                setPackage(context.packageName)
            }
            context.sendBroadcast(uiIntent)
        }
    }
}

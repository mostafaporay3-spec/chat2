package com.shadowmesh.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object MessageStore {
    private const val FILE = "shadowmesh_messages"
    private const val KEY_LIST = "history_json"
    private const val MAX_MESSAGES = 200

    @Synchronized
    fun loadAll(ctx: Context): MutableList<ChatMessage> {
        val raw = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY_LIST, "[]") ?: "[]"
        val result = mutableListOf<ChatMessage>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                result.add(
                    ChatMessage(
                        sender = obj.optString("s", "Peer"),
                        body = obj.optString("b", ""),
                        transport = obj.optString("t", "MESH"),
                        timestamp = obj.optString("ts", ""),
                        isMine = obj.optBoolean("m", false)
                    )
                )
            }
        } catch (_: Exception) {
        }
        return result
    }

    @Synchronized
    fun saveMessage(ctx: Context, msg: ChatMessage) {
        val current = loadAll(ctx)
        current.add(msg)
        val trimmed = if (current.size > MAX_MESSAGES) {
            current.subList(current.size - MAX_MESSAGES, current.size)
        } else {
            current
        }
        val arr = JSONArray()
        for (item in trimmed) {
            arr.put(
                JSONObject().apply {
                    put("s", item.sender)
                    put("b", item.body)
                    put("t", item.transport)
                    put("ts", item.timestamp)
                    put("m", item.isMine)
                }
            )
        }
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putString(KEY_LIST, arr.toString())
            .apply()
    }

    @Synchronized
    fun clearAll(ctx: Context) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .remove(KEY_LIST)
            .apply()
    }
}

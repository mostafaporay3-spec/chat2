package com.shadowmesh.app

import android.content.Context
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsClient
import com.google.android.gms.nearby.connection.ConnectionsStatusCodes
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import org.json.JSONObject
import java.util.UUID

class MeshManager(
    private val context: Context,
    private val onPeerCountChanged: (Int) -> Unit,
    private val onDecryptedMessage: (sender: String, body: String, hops: Int) -> Unit,
    private val onStatusLog: (String) -> Unit
) {
    companion object {
        private const val SERVICE_ID = "com.shadowmesh.app.PRIVATE_MESH_V1"
        private const val MAX_TTL = 5
    }

    private val client: ConnectionsClient = Nearby.getConnectionsClient(context)
    private val connectedEndpoints = mutableSetOf<String>()
    private val pendingEndpoints = mutableSetOf<String>()
    private val seenMessageIds = LinkedHashSet<String>()
    private var running = false

    fun peerCount(): Int = connectedEndpoints.size

    fun start() {
        if (running) return
        running = true
        val nick = Prefs.getNickname(context)

        val advOptions = AdvertisingOptions.Builder()
            .setStrategy(Strategy.P2P_CLUSTER)
            .build()

        client.startAdvertising(nick, SERVICE_ID, lifecycleCallback, advOptions)
            .addOnSuccessListener { onStatusLog("Mesh advertising active") }
            .addOnFailureListener { onStatusLog("Adv: ${it.localizedMessage ?: "error"}") }

        val discOptions = DiscoveryOptions.Builder()
            .setStrategy(Strategy.P2P_CLUSTER)
            .build()

        client.startDiscovery(SERVICE_ID, discoveryCallback, discOptions)
            .addOnSuccessListener { onStatusLog("Mesh scanning for squad") }
            .addOnFailureListener { onStatusLog("Scan: ${it.localizedMessage ?: "error"}") }
    }

    fun stop() {
        if (!running) return
        running = false
        client.stopAdvertising()
        client.stopDiscovery()
        client.stopAllEndpoints()
        connectedEndpoints.clear()
        pendingEndpoints.clear()
        onPeerCountChanged(0)
    }

    fun broadcastEncrypted(plainBody: String): Boolean {
        if (connectedEndpoints.isEmpty()) return false
        val secret = Prefs.getSecretKey(context)
        val nick = Prefs.getNickname(context)

        val inner = JSONObject().apply {
            put("u", nick)
            put("m", plainBody)
        }.toString()

        val msgId = UUID.randomUUID().toString().take(10)
        rememberId(msgId)

        val envelope = JSONObject().apply {
            put("id", msgId)
            put("ttl", MAX_TTL)
            put("hops", 0)
            put("enc", CryptoHelper.encrypt(inner, secret))
        }.toString()

        val payload = Payload.fromBytes(envelope.toByteArray(Charsets.UTF_8))
        client.sendPayload(connectedEndpoints.toList(), payload)
        return true
    }

    private fun rememberId(id: String) {
        if (seenMessageIds.size > 300) {
            val first = seenMessageIds.firstOrNull()
            if (first != null) seenMessageIds.remove(first)
        }
        seenMessageIds.add(id)
    }

    private val discoveryCallback = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
            if (connectedEndpoints.contains(endpointId) || pendingEndpoints.contains(endpointId)) return
            pendingEndpoints.add(endpointId)
            client.requestConnection(Prefs.getNickname(context), endpointId, lifecycleCallback)
                .addOnFailureListener {
                    pendingEndpoints.remove(endpointId)
                }
        }

        override fun onEndpointLost(endpointId: String) {
            pendingEndpoints.remove(endpointId)
        }
    }

    private val lifecycleCallback = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            pendingEndpoints.add(endpointId)
            client.acceptConnection(endpointId, payloadCallback)
        }

        override fun onConnectionResult(endpointId: String, result: ConnectionResolution) {
            pendingEndpoints.remove(endpointId)
            if (result.status.statusCode == ConnectionsStatusCodes.STATUS_OK) {
                connectedEndpoints.add(endpointId)
                onPeerCountChanged(connectedEndpoints.size)
            }
        }

        override fun onDisconnected(endpointId: String) {
            pendingEndpoints.remove(endpointId)
            connectedEndpoints.remove(endpointId)
            onPeerCountChanged(connectedEndpoints.size)
        }
    }

    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            val bytes = payload.asBytes() ?: return
            val raw = String(bytes, Charsets.UTF_8)
            try {
                val env = JSONObject(raw)
                val msgId = env.optString("id", "")
                if (msgId.isEmpty() || seenMessageIds.contains(msgId)) return
                rememberId(msgId)

                val ttl = env.optInt("ttl", 0)
                val hops = env.optInt("hops", 0) + 1
                val enc = env.optString("enc", "")
                if (enc.isEmpty()) return

                val decrypted = CryptoHelper.decrypt(enc, Prefs.getSecretKey(context))
                if (decrypted != null) {
                    val inner = JSONObject(decrypted)
                    val sender = inner.optString("u", "Peer")
                    val body = inner.optString("m", "")
                    onDecryptedMessage(sender, body, hops)
                }

                if (ttl > 1 && connectedEndpoints.size > 1) {
                    env.put("ttl", ttl - 1)
                    env.put("hops", hops)
                    val forwardBytes = env.toString().toByteArray(Charsets.UTF_8)
                    val targets = connectedEndpoints.filter { it != endpointId }
                    if (targets.isNotEmpty()) {
                        client.sendPayload(targets, Payload.fromBytes(forwardBytes))
                    }
                }
            } catch (_: Exception) {
            }
        }

        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {
        }
    }
}

package com.shadowmesh.app

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.telephony.SmsManager
import android.view.LayoutInflater
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var tvBanner: TextView
    private lateinit var btnMode: Button
    private lateinit var btnSettings: Button
    private lateinit var rvMessages: RecyclerView
    private lateinit var etMessage: EditText
    private lateinit var btnSend: Button

    private val messages = mutableListOf<ChatMessage>()
    private lateinit var adapter: ChatAdapter
    private lateinit var meshManager: MeshManager

    private var smsMode = false

    private val messagesUpdatedReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            reloadMessages()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        tvBanner = findViewById(R.id.tvBanner)
        btnMode = findViewById(R.id.btnMode)
        btnSettings = findViewById(R.id.btnSettings)
        rvMessages = findViewById(R.id.rvMessages)
        etMessage = findViewById(R.id.etMessage)
        btnSend = findViewById(R.id.btnSend)

        adapter = ChatAdapter(messages)
        rvMessages.layoutManager = LinearLayoutManager(this).apply { stackFromEnd = true }
        rvMessages.adapter = adapter

        meshManager = MeshManager(
            context = this,
            onPeerCountChanged = { _ -> runOnUiThread { updateBanner() } },
            onDecryptedMessage = { sender, body, hops ->
                MessageStore.saveMessage(
                    this,
                    ChatMessage(sender, body, "MESH(${hops}h)", nowTime(), false)
                )
                runOnUiThread { reloadMessages() }
            },
            onStatusLog = { log ->
                runOnUiThread { tvStatus.text = "AES-256-GCM | $log" }
            }
        )

        btnMode.setOnClickListener {
            smsMode = !smsMode
            updateModeUi()
        }

        btnSettings.setOnClickListener { showSettingsDialog() }

        btnSend.setOnClickListener {
            val text = etMessage.text.toString().trim()
            if (text.isEmpty()) return@setOnClickListener
            if (smsMode) sendEncryptedSms(text) else sendMeshMessage(text)
        }

        ContextCompat.registerReceiver(
            this,
            messagesUpdatedReceiver,
            IntentFilter(SmsReceiver.ACTION_MESSAGES_UPDATED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )

        reloadMessages()
        updateModeUi()
        requestAllPermissions()
    }

    override fun onResume() {
        super.onResume()
        reloadMessages()
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(messagesUpdatedReceiver)
        meshManager.stop()
    }

    private fun reloadMessages() {
        val stored = MessageStore.loadAll(this)
        adapter.replaceAll(stored)
        if (stored.isNotEmpty()) {
            rvMessages.scrollToPosition(stored.size - 1)
        }
    }

    private fun updateModeUi() {
        if (smsMode) {
            btnMode.text = "SMS 3KM+"
            btnMode.backgroundTintList = ContextCompat.getColorStateList(this, R.color.accent_amber)
        } else {
            btnMode.text = "MESH"
            btnMode.backgroundTintList = ContextCompat.getColorStateList(this, R.color.accent_cyan)
        }
        updateBanner()
    }

    private fun updateBanner() {
        if (smsMode) {
            val count = Prefs.getPhoneList(this).size
            tvBanner.text = "Long-Range Mode: Encrypted SMS (0 Internet) | Squad Numbers: $count"
            tvBanner.setTextColor(ContextCompat.getColor(this, R.color.accent_amber))
        } else {
            tvBanner.text = "Offline Mesh Mode (BT + Wi-Fi Direct) | Connected Peers: ${meshManager.peerCount()}"
            tvBanner.setTextColor(ContextCompat.getColor(this, R.color.accent_green))
        }
    }

    private fun sendMeshMessage(text: String) {
        val ok = meshManager.broadcastEncrypted(text)
        if (!ok) {
            Toast.makeText(this, "No peers connected in Mesh. Switch to SMS 3KM+ for long range.", Toast.LENGTH_SHORT).show()
            return
        }
        MessageStore.saveMessage(
            this,
            ChatMessage(Prefs.getNickname(this), text, "MESH", nowTime(), true)
        )
        reloadMessages()
        etMessage.text.clear()
    }

    private fun sendEncryptedSms(text: String) {
        val phones = Prefs.getPhoneList(this)
        if (phones.isEmpty()) {
            Toast.makeText(this, "Open SETUP and add your friends' phone numbers first.", Toast.LENGTH_LONG).show()
            showSettingsDialog()
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            requestAllPermissions()
            return
        }

        val inner = JSONObject().apply {
            put("u", Prefs.getNickname(this))
            put("m", text)
        }.toString()

        val encryptedPayload = SmsReceiver.PREFIX + CryptoHelper.encrypt(inner, Prefs.getSecretKey(this))
        val smsManager: SmsManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            getSystemService(SmsManager::class.java)
                ?: run {
                    Toast.makeText(this, "SMS service unavailable on this device.", Toast.LENGTH_SHORT).show()
                    return
                }
        } else {
            @Suppress("DEPRECATION")
            SmsManager.getDefault()
        }

        val parts = smsManager.divideMessage(encryptedPayload)
        var sentCount = 0
        for (number in phones) {
            try {
                smsManager.sendMultipartTextMessage(number, null, parts, null, null)
                sentCount++
            } catch (_: Exception) {
                Toast.makeText(this, "SMS failed for $number", Toast.LENGTH_SHORT).show()
            }
        }
        if (sentCount > 0) {
            MessageStore.saveMessage(
                this,
                ChatMessage(Prefs.getNickname(this), text, "SMS-AES($sentCount)", nowTime(), true)
            )
            reloadMessages()
            etMessage.text.clear()
        }
    }

    private fun showSettingsDialog() {
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_settings, null)
        val etNick = view.findViewById<EditText>(R.id.etNickname)
        val etKey = view.findViewById<EditText>(R.id.etSecretKey)
        val etPhones = view.findViewById<EditText>(R.id.etPhones)
        val btnClear = view.findViewById<Button>(R.id.btnClearChat)

        etNick.setText(Prefs.getNickname(this))
        etKey.setText(Prefs.getSecretKey(this))
        etPhones.setText(Prefs.getPhonesRaw(this))

        val dialog = AlertDialog.Builder(this)
            .setView(view)
            .setPositiveButton("SAVE") { _, _ ->
                Prefs.save(this, etNick.text.toString(), etKey.text.toString(), etPhones.text.toString())
                meshManager.stop()
                meshManager.start()
                updateBanner()
                Toast.makeText(this, "Squad settings updated", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("CANCEL", null)
            .create()

        btnClear.setOnClickListener {
            MessageStore.clearAll(this)
            reloadMessages()
            Toast.makeText(this, "Chat history wiped", Toast.LENGTH_SHORT).show()
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun nowTime(): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())

    private fun requestAllPermissions() {
        val needed = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.SEND_SMS,
            Manifest.permission.RECEIVE_SMS
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            needed.add(Manifest.permission.BLUETOOTH_ADVERTISE)
            needed.add(Manifest.permission.BLUETOOTH_CONNECT)
            needed.add(Manifest.permission.BLUETOOTH_SCAN)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            needed.add(Manifest.permission.NEARBY_WIFI_DEVICES)
        }

        val missing = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 101)
        } else {
            meshManager.start()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        meshManager.start()
    }
}
